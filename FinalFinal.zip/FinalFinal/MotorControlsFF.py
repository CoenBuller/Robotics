import picar_4wd as fc
from typing import Optional


class MotorControl():

    def __init__(
        self,
        power_forward: int = 20,
        power_backward: int = 20,
        power_steer: int = 5,
        classes: Optional[dict[int, str]] = None,
        high_notes: Optional[set[str]] = None,
        motor_controls: bool = True
    ):

        self.power_forward = power_forward
        self.power_backward = power_backward
        self.power_steer = power_steer

        self.motor_controls = motor_controls

        self._forward = False
        self._backward = False

        # ---------------------------------------
        # SOUND LABELS
        # 0 = clap
        # 1 = harmonica
        # 2 = silence
        # 3 = whistle
        # ---------------------------------------

        if classes is None:
            self.moves = {
                0: "clap",
                1: "turn",
                2: "none",
                3: "whistle"
            }
        else:
            self.moves = classes

        if high_notes is None:
            self.high_notes = set(
                ['D#', 'E', 'F', 'F#', 'G', 'G#']
            )
        else:
            self.high_notes = high_notes

    # =====================================================
    # PROPERTIES
    # =====================================================

    @property
    def forward(self):
        return self._forward

    @forward.setter
    def forward(self, value):
        assert isinstance(value, bool)
        self._forward = value

    @property
    def backward(self):
        return self._backward

    @backward.setter
    def backward(self, value):
        assert isinstance(value, bool)
        self._backward = value

    @property
    def turning(self):
        return False

    # =====================================================
    # EXECUTE ACTIONS
    # =====================================================

    def _execute_action(self, action):

        if not self.motor_controls:
            return

        if action == "forward":
            fc.forward(self.power_forward)

        elif action == "backward":
            fc.backward(self.power_backward)

        elif action == "left":
            fc.turn_left(self.power_steer)

        elif action == "right":
            fc.turn_right(self.power_steer)

        elif action == "stop":
            fc.stop()

    # =====================================================
    # MAIN STATE MACHINE
    # =====================================================

    def __call__(self, label, note):

        move = self.moves[label]

        action = None

        # -------------------------------------------------
        # CLAP
        # -------------------------------------------------

        if move == "clap":

            # backward -> stop
            if self.backward:

                self.backward = False

                action = "stop"

            # stopped -> forward
            elif not self.forward:

                self.forward = True
                self.backward = False

                action = "forward"

        # -------------------------------------------------
        # WHISTLE
        # -------------------------------------------------

        elif move == "whistle":

            # forward -> stop
            if self.forward:

                self.forward = False

                action = "stop"

            # stopped -> backward
            elif not self.backward:

                self.backward = True
                self.forward = False

                action = "backward"

        # -------------------------------------------------
        # HARMONICA = TURNING
        # -------------------------------------------------

        elif move == "turn":
            if self.forward or self.backward:
                if note in self.high_notes:
                    action = "right"
                else:
                    action = "left"

        # -------------------------------------------------
        # EXECUTE
        # -------------------------------------------------

        if action is not None:

            self._execute_action(action)

            return action

        return None